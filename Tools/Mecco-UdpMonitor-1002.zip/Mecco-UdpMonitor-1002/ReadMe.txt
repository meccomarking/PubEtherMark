Mecco UdpMonitor Diagnostic Tool 

Features
    * Captures UDP port 514 syslog broadcasts 
    * Displays syslog in on-screen buffer, allowing cut & paste
    * Buffer can be paused, to permit cut & paste selection
    * Records log to disk file
    * Button to compress log file to zip archive

Allow UdpMonitor to operate with Windows Firewall

    * If using Windows 7
        * Click Start, click Control Panel.
        * Open Windows Firewall or Security.
    * If using Windows 10
        * Click Start, click gear icon, or type "settings"
        * Click Network & Internet
        * On left, click Status
		* In the panel on the right, click Windows Firewall
    * Click Allow a program through Windows Firewall.
    * Scroll down the list to locate udpmonitor.exe.
    * If udpmonitor.exe does not appear in the list...
        * Click Allow [another] program or Allow another app
        * Click the Browse button, locate udpmonitor.exe, and select it
        * Click the Add button.
        * Click OK.
    * Locate udpmonitor.exe in the list of programs
        * Check the checkbox [x] to the left of udpmonitor.exe.
        * Check the checkbox [x] in the Home/Work (Private) column
        * Check the checkbox [x] in the Public column
    * Click OK.

To install Mecco UdpMonitor
    
    * Extract contents of zip archive UdpMonitor-Install-1000.zip
    * Execute setup.exe
    * Application Install - Security Warning pops up
        * Publisher cannot be verified.
        * Are you sure you want to install this application?
        * Click Install
    * Windows Security Alert pops up
        * Windows Firewall has blocked some features of this program
        * Allow UdpMonitor to communicate on these networks:
            * [x] Private networks
        * Click Allow access button
    * Launch the program
        * Open Windows Start Menu (click Start Button)
        * Click All Programs
        * Locate and click Mecco folder to open it
        * Click to launch Mecco-UdpMonitor
        * Optionally double-click the desktop shortcut Mecco-UdpMonitor


